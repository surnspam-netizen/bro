@echo off
rem Needs JDK 17+ and Maven. Output: target\Eyebound-1.0.0.jar (also copied to server\plugins\)
call mvn -q clean package && copy /y target\Eyebound-1.0.0.jar server\plugins\ && echo Done
pause
