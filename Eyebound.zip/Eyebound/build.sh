#!/usr/bin/env bash
# Needs JDK 17+ and Maven. Output: target/Eyebound-1.0.0.jar (also copied to server/plugins/)
mvn -q clean package && cp target/Eyebound-1.0.0.jar server/plugins/ && echo "Done: server/plugins/Eyebound-1.0.0.jar"
