package dev.eyes;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.BoundingBox;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Transformation;
import org.bukkit.util.Vector;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.*;
import java.util.function.IntConsumer;

public class Abilities {
    // custom_model_data values used by the resource pack
    public static final int CMD_CLOUD = 2001, CMD_VINE = 2002, CMD_VOID = 2003, CMD_LASER = 2004;

    private final EyesPlugin plugin;
    private final Map<String, Long> cooldowns = new HashMap<>();
    private final Set<Runnable> cleanups = new HashSet<>();
    private final Set<UUID> hidden = new HashSet<>();
    private final Random rng = new Random();

    public Abilities(EyesPlugin plugin) { this.plugin = plugin; }

    public boolean isHidden(UUID id) { return hidden.contains(id); }

    public void shutdown() {
        for (Runnable r : new ArrayList<>(cleanups)) r.run();
        cleanups.clear();
    }

    // ---------- entry point ----------
    public void use(Player p, boolean secondary) {
        Eye e = plugin.manager().activeEye(p);
        if (e == null) {
            p.sendMessage(Component.text("No eye in the active slot. Right-click the Eye Wheel to equip one.", NamedTextColor.GRAY));
            return;
        }
        switch (e) {
            case CLOUD -> { if (!secondary) cloud(p); }
            case NATURE -> { if (!secondary) nature(p); }
            case FIRE -> { if (secondary) fireForm(p); else inferno(p); }
            case VOID -> { if (!secondary) voidPuddle(p); }
            case LASER -> { if (!secondary) laser(p); }
        }
    }

    // ---------- helpers ----------
    private boolean ready(Player p, String key, String cfgKey) {
        long now = System.currentTimeMillis();
        String k = p.getUniqueId() + key;
        Long until = cooldowns.get(k);
        if (until != null && until > now) {
            long left = (until - now + 999) / 1000;
            p.sendMessage(Component.text("Ability on cooldown: " + left + "s", NamedTextColor.RED));
            return false;
        }
        cooldowns.put(k, now + plugin.getConfig().getInt("cooldowns." + cfgKey, 30) * 1000L);
        return true;
    }

    private int ticks(String key) { return plugin.getConfig().getInt("durations." + key, 10) * 20; }

    private void timed(Player owner, int ticks, IntConsumer tick, Runnable end) {
        final boolean[] done = {false};
        final Runnable[] fin = new Runnable[1];
        fin[0] = () -> {
            if (done[0]) return;
            done[0] = true;
            try { end.run(); } catch (Exception ignored) { }
            cleanups.remove(fin[0]);
        };
        cleanups.add(fin[0]);
        new BukkitRunnable() {
            int t = 0;
            @Override public void run() {
                if (done[0]) { cancel(); return; }
                if (!owner.isOnline() || owner.isDead() || t >= ticks) { fin[0].run(); cancel(); return; }
                tick.accept(t);
                t++;
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }

    public ItemDisplay sprite(Location l, int cmd, float scale, boolean flat, Display.Billboard billboard) {
        ItemStack it = new ItemStack(Material.PAPER);
        ItemMeta m = it.getItemMeta();
        m.setCustomModelData(cmd);
        it.setItemMeta(m);
        return l.getWorld().spawn(l, ItemDisplay.class, d -> {
            d.setItemStack(it);
            d.setPersistent(false);
            d.setBillboard(billboard);
            Quaternionf q = flat ? new Quaternionf().rotateX((float) Math.toRadians(-90)) : new Quaternionf();
            d.setTransformation(new Transformation(new Vector3f(), q, new Vector3f(scale, scale, scale), new Quaternionf()));
        });
    }

    private boolean valid(Player owner, Entity en) {
        if (!(en instanceof LivingEntity le) || en.equals(owner) || en instanceof ArmorStand) return false;
        return !(le instanceof Player pl && (pl.getGameMode() == GameMode.SPECTATOR || pl.getGameMode() == GameMode.CREATIVE));
    }

    // ---------- CLOUD EYE: fly on a cloud ----------
    private void cloud(Player p) {
        if (!ready(p, "cloud", "cloud")) return;
        boolean hadFlight = p.getAllowFlight();
        p.setAllowFlight(true);
        p.setFlying(true);
        ItemDisplay d = sprite(p.getLocation().add(0, -0.1, 0), CMD_CLOUD, 2.4f, true, Display.Billboard.FIXED);
        p.getWorld().playSound(p.getLocation(), Sound.ENTITY_PHANTOM_FLAP, 1f, 1.6f);
        timed(p, ticks("cloud"), t -> {
            d.teleport(p.getLocation().add(0, -0.1, 0));
            p.getWorld().spawnParticle(Particle.CLOUD, p.getLocation(), 2, 0.5, 0.05, 0.5, 0.01);
        }, () -> {
            d.remove();
            GameMode gm = p.getGameMode();
            if (!hadFlight && gm != GameMode.CREATIVE && gm != GameMode.SPECTATOR) {
                p.setFlying(false);
                p.setAllowFlight(false);
            }
        });
    }

    // ---------- NATURE EYE: vines ----------
    private void nature(Player p) {
        if (!ready(p, "nature", "nature")) return;
        Location c = p.getLocation().clone();
        double r = plugin.getConfig().getDouble("nature.radius", 4.5);
        double perStack = plugin.getConfig().getDouble("nature.damage-per-stack", 2.0);
        int maxStacks = plugin.getConfig().getInt("nature.max-stacks", 5);
        List<ItemDisplay> vines = new ArrayList<>();
        for (int i = 0; i < 14; i++) {
            double ang = rng.nextDouble() * Math.PI * 2, dist = Math.sqrt(rng.nextDouble()) * r;
            Location l = c.clone().add(Math.cos(ang) * dist, 0.8, Math.sin(ang) * dist);
            vines.add(sprite(l, CMD_VINE, 1.7f, false, Display.Billboard.VERTICAL));
        }
        p.getWorld().playSound(c, Sound.BLOCK_AZALEA_LEAVES_BREAK, 1.5f, 0.6f);
        Map<UUID, Integer> stacks = new HashMap<>();
        timed(p, ticks("nature"), t -> {
            if (t % 20 == 0) {
                Set<UUID> inside = new HashSet<>();
                for (Entity en : c.getWorld().getNearbyEntities(c, r, 3, r)) {
                    if (!valid(p, en)) continue;
                    double dx = en.getLocation().getX() - c.getX(), dz = en.getLocation().getZ() - c.getZ();
                    if (dx * dx + dz * dz > r * r) continue;
                    LivingEntity le = (LivingEntity) en;
                    inside.add(en.getUniqueId());
                    int s = Math.min(maxStacks, stacks.merge(en.getUniqueId(), 1, Integer::sum));
                    le.damage(perStack * s, p);
                    le.addPotionEffect(new PotionEffect(PotionEffectType.SLOW, 30, 1, false, false, false));
                }
                stacks.keySet().retainAll(inside);
            }
            if (t % 4 == 0) {
                double ang = rng.nextDouble() * Math.PI * 2, dist = Math.sqrt(rng.nextDouble()) * r;
                c.getWorld().spawnParticle(Particle.COMPOSTER, c.clone().add(Math.cos(ang) * dist, 0.2, Math.sin(ang) * dist), 2, 0.1, 0.3, 0.1, 0);
            }
        }, () -> vines.forEach(Entity::remove));
    }

    // ---------- FIRE EYE: inferno pulse ----------
    private void inferno(Player p) {
        if (!ready(p, "inferno", "fire-inferno")) return;
        double r = plugin.getConfig().getDouble("fire.radius", 8.0);
        double dmg = plugin.getConfig().getDouble("fire.burn-damage", 1.5);
        List<LivingEntity> targets = new ArrayList<>();
        for (Entity en : p.getNearbyEntities(r, r, r)) if (valid(p, en)) targets.add((LivingEntity) en);
        p.getWorld().playSound(p.getLocation(), Sound.ITEM_FIRECHARGE_USE, 1.5f, 0.7f);
        p.getWorld().spawnParticle(Particle.FLAME, p.getLocation().add(0, 1, 0), 80, r / 3, 0.5, r / 3, 0.05);
        timed(p, ticks("fire-inferno"), t -> {
            for (LivingEntity le : targets) {
                if (le.isDead() || !le.isValid()) continue;
                if (t % 5 == 0) le.setFireTicks(Math.max(le.getFireTicks(), 40)); // re-ignites even after water
                if (t % 20 == 10) le.damage(dmg, p);                              // direct damage ignores fire resistance
                if (t % 6 == 0) le.getWorld().spawnParticle(Particle.FLAME, le.getLocation().add(0, 1, 0), 3, 0.3, 0.5, 0.3, 0.01);
            }
        }, () -> { });
    }

    // ---------- FIRE EYE: fire form ----------
    private void fireForm(Player p) {
        if (!ready(p, "fireform", "fire-form")) return;
        int lvl = Math.max(1, plugin.getConfig().getInt("fire.form-strength-level", 2));
        int dur = ticks("fire-form");
        p.addPotionEffect(new PotionEffect(PotionEffectType.INCREASE_DAMAGE, dur, lvl - 1, false, true, true));
        p.addPotionEffect(new PotionEffect(PotionEffectType.FIRE_RESISTANCE, dur, 0, false, false, true));
        p.setVisualFire(true);
        p.getWorld().playSound(p.getLocation(), Sound.ENTITY_BLAZE_SHOOT, 1.5f, 0.8f);
        timed(p, dur, t -> {
            p.getWorld().spawnParticle(Particle.FLAME, p.getLocation().add(0, 1, 0), 4, 0.35, 0.7, 0.35, 0.02);
            if (t % 10 == 0) {
                for (Entity en : p.getNearbyEntities(2.5, 2.5, 2.5)) if (valid(p, en)) en.setFireTicks(60);
            }
        }, () -> p.setVisualFire(false));
    }

    // ---------- VOID EYE ----------
    private void voidPuddle(Player p) {
        if (!ready(p, "void", "void")) return;
        ItemDisplay puddle = sprite(p.getLocation().add(0, 0.03, 0), CMD_VOID, 2.2f, true, Display.Billboard.FIXED);
        hidden.add(p.getUniqueId());
        for (Player o : Bukkit.getOnlinePlayers()) if (!o.equals(p)) o.hidePlayer(plugin, p);
        p.setSilent(true); // no footstep / movement sounds for everyone else
        p.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, ticks("void"), 3, false, false, false));
        p.getWorld().playSound(p.getLocation(), Sound.ENTITY_ENDERMAN_TELEPORT, 0.6f, 0.5f);
        timed(p, ticks("void"), t -> {
            puddle.teleport(p.getLocation().add(0, 0.03, 0));
            if (t % 3 == 0) p.getWorld().spawnParticle(Particle.REVERSE_PORTAL, p.getLocation().add(0, 0.1, 0), 3, 0.5, 0.05, 0.5, 0.02);
        }, () -> {
            hidden.remove(p.getUniqueId());
            for (Player o : Bukkit.getOnlinePlayers()) if (!o.equals(p)) o.showPlayer(plugin, p);
            p.setSilent(false);
            p.removePotionEffect(PotionEffectType.SPEED);
            puddle.remove();
        });
    }

    // ---------- LASER EYE ----------
    private void laser(Player p) {
        if (!ready(p, "laser", "laser")) return;
        double range = plugin.getConfig().getDouble("laser.range", 30.0);
        double dmg = plugin.getConfig().getDouble("laser.damage", 6.0);
        double beamR = plugin.getConfig().getDouble("laser.beam-radius", 1.2);
        final int N = 44;
        final double STEP = 0.7;
        List<ItemDisplay> pool = new ArrayList<>();
        Location eye0 = p.getEyeLocation();
        for (int i = 0; i < N; i++) pool.add(sprite(eye0, CMD_LASER, 1.0f, false, Display.Billboard.CENTER));
        p.getWorld().playSound(eye0, Sound.BLOCK_BEACON_ACTIVATE, 1.5f, 1.8f);
        Particle.DustOptions dust = new Particle.DustOptions(Color.fromRGB(255, 30, 30), 1.8f);
        timed(p, ticks("laser"), t -> {
            Location eye = p.getEyeLocation();
            Vector dir = eye.getDirection().normalize();
            RayTraceResult br = eye.getWorld().rayTraceBlocks(eye, dir, range, FluidCollisionMode.NEVER, true);
            double len = br != null ? br.getHitPosition().distance(eye.toVector()) : range;
            Vector startV = eye.toVector().add(dir.clone().multiply(0.9)).add(new Vector(0, -0.2, 0));
            Vector endV = eye.toVector().add(dir.clone().multiply(len));
            int count = Math.max(1, Math.min(N, (int) ((len - 0.9) / STEP)));
            for (int i = 0; i < N; i++) {
                Vector pos = i < count ? startV.clone().add(dir.clone().multiply(i * STEP)) : endV.clone();
                pool.get(i).teleport(pos.toLocation(eye.getWorld()));
            }
            if (t % 2 == 0)
                for (double d = 1; d < len; d += 1.0)
                    eye.getWorld().spawnParticle(Particle.REDSTONE, eye.toVector().add(dir.clone().multiply(d)).toLocation(eye.getWorld()), 1, 0.1, 0.1, 0.1, 0, dust);
            if (t % 20 == 5) {
                BoundingBox box = BoundingBox.of(startV, endV).expand(beamR + 0.5);
                for (Entity en : eye.getWorld().getNearbyEntities(box)) {
                    if (!valid(p, en)) continue;
                    Vector c = en.getBoundingBox().getCenter();
                    if (distToSegment(c, startV, endV) <= beamR) {
                        LivingEntity le = (LivingEntity) en;
                        le.damage(dmg, p);
                        le.getWorld().spawnParticle(Particle.FLAME, le.getLocation().add(0, 1, 0), 6, 0.2, 0.4, 0.2, 0.02);
                    }
                }
            }
        }, () -> pool.forEach(Entity::remove));
    }

    private static double distToSegment(Vector p, Vector a, Vector b) {
        Vector ab = b.clone().subtract(a);
        double l2 = ab.lengthSquared();
        if (l2 == 0) return p.distance(a);
        double t = Math.max(0, Math.min(1, p.clone().subtract(a).dot(ab) / l2));
        return p.distance(a.clone().add(ab.multiply(t)));
    }
}
