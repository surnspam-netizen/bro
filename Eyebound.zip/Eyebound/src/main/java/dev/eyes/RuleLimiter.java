package dev.eyes;

import org.bukkit.NamespacedKey;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.enchantment.EnchantItemEvent;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.entity.EntityPotionEffectEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.PrepareAnvilEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.EnchantmentStorageMeta;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.potion.PotionEffectType;

import java.util.HashMap;
import java.util.Map;

/** Server rules: max enchant levels (Protection 3, Sharpness 2) and no Strength II (abilities exempt). */
public class RuleLimiter implements Listener {
    private final EyesPlugin plugin;

    public RuleLimiter(EyesPlugin plugin) { this.plugin = plugin; }

    private Map<Enchantment, Integer> limits() {
        Map<Enchantment, Integer> map = new HashMap<>();
        ConfigurationSection s = plugin.getConfig().getConfigurationSection("rules.max-enchant-levels");
        if (s == null) return map;
        for (String key : s.getKeys(false)) {
            Enchantment en = Enchantment.getByKey(NamespacedKey.minecraft(key.toLowerCase()));
            if (en != null) map.put(en, s.getInt(key));
        }
        return map;
    }

    private boolean clamp(ItemStack it) {
        if (it == null || !it.hasItemMeta()) return false;
        Map<Enchantment, Integer> lim = limits();
        ItemMeta m = it.getItemMeta();
        boolean changed = false;
        for (Map.Entry<Enchantment, Integer> en : new HashMap<>(m.getEnchants()).entrySet()) {
            Integer max = lim.get(en.getKey());
            if (max != null && en.getValue() > max) {
                m.removeEnchant(en.getKey());
                m.addEnchant(en.getKey(), max, true);
                changed = true;
            }
        }
        if (m instanceof EnchantmentStorageMeta sm) {
            for (Map.Entry<Enchantment, Integer> en : new HashMap<>(sm.getStoredEnchants()).entrySet()) {
                Integer max = lim.get(en.getKey());
                if (max != null && en.getValue() > max) {
                    sm.removeStoredEnchant(en.getKey());
                    sm.addStoredEnchant(en.getKey(), max, true);
                    changed = true;
                }
            }
        }
        if (changed) it.setItemMeta(m);
        return changed;
    }

    private void sweep(Player p) {
        for (ItemStack it : p.getInventory().getContents()) clamp(it);
        for (ItemStack it : p.getInventory().getArmorContents()) clamp(it);
    }

    @EventHandler
    public void onEnchant(EnchantItemEvent e) {
        Map<Enchantment, Integer> lim = limits();
        for (Map.Entry<Enchantment, Integer> en : e.getEnchantsToAdd().entrySet()) {
            Integer max = lim.get(en.getKey());
            if (max != null && en.getValue() > max) en.setValue(max);
        }
    }

    @EventHandler
    public void onAnvil(PrepareAnvilEvent e) {
        ItemStack r = e.getResult();
        if (r == null) return;
        r = r.clone();
        if (clamp(r)) e.setResult(r);
    }

    @EventHandler public void onJoin(PlayerJoinEvent e) { sweep(e.getPlayer()); }
    @EventHandler public void onClose(InventoryCloseEvent e) { if (e.getPlayer() instanceof Player p) sweep(p); }

    @EventHandler
    public void onPickup(EntityPickupItemEvent e) {
        if (!(e.getEntity() instanceof Player)) return;
        Item item = e.getItem();
        ItemStack st = item.getItemStack().clone();
        if (clamp(st)) item.setItemStack(st);
    }

    @EventHandler
    public void onEffect(EntityPotionEffectEvent e) {
        if (!plugin.getConfig().getBoolean("rules.block-strength-2", true)) return;
        if (e.getNewEffect() == null) return;
        if (e.getNewEffect().getType().equals(PotionEffectType.INCREASE_DAMAGE)
                && e.getNewEffect().getAmplifier() >= 1
                && e.getCause() != EntityPotionEffectEvent.Cause.PLUGIN) e.setCancelled(true);
    }
}
