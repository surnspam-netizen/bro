package dev.eyes;

import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class EyeManager {
    private final EyesPlugin plugin;
    private final File file;
    private final YamlConfiguration yml;
    private final Map<UUID, Eye[]> slots = new HashMap<>();
    private final Map<UUID, Integer> active = new HashMap<>();

    public EyeManager(EyesPlugin plugin) {
        this.plugin = plugin;
        plugin.getDataFolder().mkdirs();
        this.file = new File(plugin.getDataFolder(), "data.yml");
        this.yml = YamlConfiguration.loadConfiguration(file);
    }

    public Eye[] get(UUID id) {
        return slots.computeIfAbsent(id, k -> new Eye[]{
                Eye.parse(yml.getString(k + ".1")), Eye.parse(yml.getString(k + ".2"))});
    }

    public int activeSlot(UUID id) {
        return active.computeIfAbsent(id, k -> yml.getInt(k + ".active", 0));
    }

    public Eye activeEye(Player p) {
        return get(p.getUniqueId())[activeSlot(p.getUniqueId())];
    }

    public boolean has(Player p, Eye e) {
        for (Eye x : get(p.getUniqueId())) if (x == e) return true;
        return false;
    }

    public void swapActive(Player p) {
        active.put(p.getUniqueId(), 1 - activeSlot(p.getUniqueId()));
        save();
    }

    public void equip(Player p, int slot, Eye e) {
        Eye[] s = get(p.getUniqueId());
        int other = 1 - slot;
        if (s[other] == e) s[other] = s[slot];
        s[slot] = e;
        save();
    }

    public void save() {
        for (Map.Entry<UUID, Eye[]> en : slots.entrySet()) {
            String k = en.getKey().toString();
            yml.set(k + ".1", en.getValue()[0] == null ? null : en.getValue()[0].name());
            yml.set(k + ".2", en.getValue()[1] == null ? null : en.getValue()[1].name());
            yml.set(k + ".active", activeSlot(en.getKey()));
        }
        try { yml.save(file); } catch (IOException ex) { plugin.getLogger().warning("Could not save data.yml: " + ex.getMessage()); }
    }
}
