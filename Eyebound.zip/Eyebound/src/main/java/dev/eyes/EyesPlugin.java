package dev.eyes;

import net.kyori.adventure.key.Key;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.List;

public class EyesPlugin extends JavaPlugin {
    public static final int WHEEL_CMD = 1100;
    private EyeManager manager;
    private Abilities abilities;
    private EyeGui gui;

    public EyeManager manager() { return manager; }
    public Abilities abilities() { return abilities; }
    public EyeGui gui() { return gui; }

    @Override public void onEnable() {
        saveDefaultConfig();
        manager = new EyeManager(this);
        abilities = new Abilities(this);
        gui = new EyeGui(this);
        var pm = getServer().getPluginManager();
        pm.registerEvents(new EyeListener(this), this);
        pm.registerEvents(gui, this);
        pm.registerEvents(new RuleLimiter(this), this);
        Bukkit.getScheduler().runTaskTimer(this, this::tick, 20L, 10L);
        getLogger().info("Eyebound enabled.");
    }

    @Override public void onDisable() {
        if (abilities != null) abilities.shutdown();
        if (manager != null) manager.save();
    }

    private void tick() {
        for (Player p : Bukkit.getOnlinePlayers()) {
            passives(p);
            actionBar(p);
        }
    }

    private void passives(Player p) {
        for (Eye e : manager.get(p.getUniqueId())) {
            if (e == null) continue;
            PotionEffectType t = switch (e) {
                case NATURE -> PotionEffectType.HERO_OF_THE_VILLAGE;
                case FIRE -> PotionEffectType.FIRE_RESISTANCE;
                case LASER -> PotionEffectType.DAMAGE_RESISTANCE;
                default -> null;
            };
            if (t == null) continue;
            PotionEffect cur = p.getPotionEffect(t);
            if (cur != null && cur.getDuration() > 60) continue; // don't shorten ability-granted effects
            p.addPotionEffect(new PotionEffect(t, 60, 0, false, false, true)); // refreshed constantly = permanent while equipped
        }
    }

    /** Shows the equipped eyes above the xp bar, like  0 - 0  (empty) or  [eye] - [eye]. */
    private void actionBar(Player p) {
        Eye[] s = manager.get(p.getUniqueId());
        int act = manager.activeSlot(p.getUniqueId());
        Component bar = Component.empty();
        for (int i = 0; i < 2; i++) {
            Component part;
            NamedTextColor col = i == act ? NamedTextColor.WHITE : NamedTextColor.DARK_GRAY;
            if (s[i] == null) part = Component.text("0", col);
            else part = Component.text(String.valueOf(s[i].glyph), col).font(Key.key("eyes", "icons"));
            bar = bar.append(part);
            if (i == 0) bar = bar.append(Component.text(" - ", NamedTextColor.GRAY));
        }
        p.sendActionBar(bar);
    }

    public static ItemStack wheel() {
        ItemStack it = new ItemStack(Material.ENDER_EYE);
        ItemMeta m = it.getItemMeta();
        m.setCustomModelData(WHEEL_CMD);
        m.displayName(Component.text("Eye Wheel", NamedTextColor.AQUA).decoration(TextDecoration.ITALIC, false));
        m.lore(List.of(
                Component.text("Right-click: open the wheel", NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false),
                Component.text("Left-click: switch active eye slot", NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false),
                Component.text("F: ability 1  |  Shift+F: ability 2", NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false)));
        it.setItemMeta(m);
        return it;
    }

    public static boolean isWheel(ItemStack it) {
        return it != null && it.getType() == Material.ENDER_EYE && it.hasItemMeta()
                && it.getItemMeta().hasCustomModelData() && it.getItemMeta().getCustomModelData() == WHEEL_CMD;
    }

    @Override public boolean onCommand(CommandSender sender, Command cmd, String label, String[] a) {
        if (!(sender instanceof Player p)) { sender.sendMessage("Players only."); return true; }
        String sub = a.length == 0 ? "gui" : a[0].toLowerCase();
        switch (sub) {
            case "wheel" -> p.getInventory().addItem(wheel());
            case "gui" -> gui.open(p);
            case "use" -> abilities.use(p, a.length > 1 && a[1].equalsIgnoreCase("secondary"));
            case "equip" -> {
                if (a.length < 3) { p.sendMessage("/eyes equip <1|2> <cloud|nature|fire|void|laser>"); break; }
                Eye e = Eye.parse(a[2]);
                if (e == null) { p.sendMessage("Unknown eye."); break; }
                manager.equip(p, a[1].equals("2") ? 1 : 0, e);
                p.sendMessage(Component.text("Equipped " + e.display, e.color));
            }
            case "reload" -> {
                if (!p.isOp()) { p.sendMessage("No permission."); break; }
                reloadConfig();
                p.sendMessage("Config reloaded.");
            }
            default -> p.sendMessage("/eyes [wheel|gui|use|equip|reload]");
        }
        return true;
    }
}
