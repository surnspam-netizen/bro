package dev.eyes;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

/** Pentagon-shaped "wheel" of the five eyes. Left-click = equip in slot 1, right-click = equip in slot 2. */
public class EyeGui implements Listener {
    private static final int[] POS = {4, 25, 33, 29, 19}; // clockwise from the top
    private static final int CENTER = 22;
    private final EyesPlugin plugin;

    public EyeGui(EyesPlugin plugin) { this.plugin = plugin; }

    static class Holder implements InventoryHolder {
        @Override public Inventory getInventory() { return null; }
    }

    private static Component line(String s, NamedTextColor c) {
        return Component.text(s, c).decoration(TextDecoration.ITALIC, false);
    }

    public void open(Player p) {
        Inventory inv = Bukkit.createInventory(new Holder(), 36, Component.text("Eye Wheel"));
        render(inv, p);
        p.openInventory(inv);
    }

    private void render(Inventory inv, Player p) {
        ItemStack pane = new ItemStack(Material.GRAY_STAINED_GLASS_PANE);
        ItemMeta pm = pane.getItemMeta();
        pm.displayName(Component.text(" "));
        pane.setItemMeta(pm);
        for (int i = 0; i < inv.getSize(); i++) inv.setItem(i, pane);
        Eye[] all = Eye.values();
        Eye[] eq = plugin.manager().get(p.getUniqueId());
        for (int i = 0; i < all.length; i++) inv.setItem(POS[i], eyeItem(all[i], eq));
        ItemStack c = new ItemStack(Material.ENDER_EYE);
        ItemMeta cm = c.getItemMeta();
        cm.displayName(line("Equipped eyes", NamedTextColor.AQUA));
        int act = plugin.manager().activeSlot(p.getUniqueId());
        List<Component> lore = new ArrayList<>();
        for (int i = 0; i < 2; i++)
            lore.add(line("Slot " + (i + 1) + (i == act ? " (active): " : ": ") + (eq[i] == null ? "empty" : eq[i].display),
                    eq[i] == null ? NamedTextColor.DARK_GRAY : eq[i].color));
        lore.add(line("Left-click an eye: equip to slot 1", NamedTextColor.GRAY));
        lore.add(line("Right-click an eye: equip to slot 2", NamedTextColor.GRAY));
        cm.lore(lore);
        c.setItemMeta(cm);
        inv.setItem(CENTER, c);
    }

    private ItemStack eyeItem(Eye e, Eye[] eq) {
        ItemStack it = new ItemStack(Material.PAPER);
        ItemMeta m = it.getItemMeta();
        m.setCustomModelData(e.cmd);
        m.displayName(line(e.display, e.color));
        List<Component> lore = new ArrayList<>();
        lore.add(line("Ability 1 (F): " + e.primary, NamedTextColor.YELLOW));
        if (e.secondary != null) lore.add(line("Ability 2 (Shift+F): " + e.secondary, NamedTextColor.YELLOW));
        lore.add(line("Passive: " + e.passive, NamedTextColor.GREEN));
        if (eq[0] == e) lore.add(line("Equipped in slot 1", NamedTextColor.AQUA));
        if (eq[1] == e) lore.add(line("Equipped in slot 2", NamedTextColor.AQUA));
        m.lore(lore);
        it.setItemMeta(m);
        return it;
    }

    @EventHandler
    public void onClick(InventoryClickEvent ev) {
        if (!(ev.getView().getTopInventory().getHolder() instanceof Holder)) return;
        ev.setCancelled(true);
        if (!(ev.getWhoClicked() instanceof Player p)) return;
        if (ev.getClickedInventory() != ev.getView().getTopInventory()) return;
        for (int i = 0; i < POS.length; i++) {
            if (ev.getSlot() == POS[i]) {
                plugin.manager().equip(p, ev.isRightClick() ? 1 : 0, Eye.values()[i]);
                p.playSound(p.getLocation(), Sound.BLOCK_AMETHYST_BLOCK_CHIME, 1f, 1.4f);
                render(ev.getView().getTopInventory(), p);
                return;
            }
        }
    }

    @EventHandler
    public void onDrag(InventoryDragEvent ev) {
        if (ev.getView().getTopInventory().getHolder() instanceof Holder) ev.setCancelled(true);
    }
}
