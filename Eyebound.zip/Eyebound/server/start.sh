#!/usr/bin/env bash
# Put paper-1.20.4-*.jar next to this file and name it paper.jar
cd "$(dirname "$0")"
[ -f paper.jar ] || { echo "Download Paper 1.20.4 from https://papermc.io/downloads/paper and save it here as paper.jar"; exit 1; }
[ -f eula.txt ] || { java -jar paper.jar --nogui; echo "Set eula=true in eula.txt, then run this script again."; exit 0; }
java -Xms2G -Xmx4G -jar paper.jar --nogui
